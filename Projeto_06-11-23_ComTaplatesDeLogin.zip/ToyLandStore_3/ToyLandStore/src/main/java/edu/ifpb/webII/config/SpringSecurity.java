package edu.ifpb.webII.config;

public class SpringSecurity {

}
