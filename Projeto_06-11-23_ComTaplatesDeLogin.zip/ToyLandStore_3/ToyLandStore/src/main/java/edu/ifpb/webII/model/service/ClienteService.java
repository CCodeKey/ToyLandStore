package edu.ifpb.webII.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.ifpb.webII.model.Cliente;
import edu.ifpb.webII.repository.ClienteRepository;

@Service
public class ClienteService {
	@Autowired
	private ClienteRepository clienteRepository;

	public List<Cliente> listarCliente() {
		return clienteRepository.findAll();
	}

	public Cliente cadastrarCliente(Cliente cliente) {
		return clienteRepository.save(cliente);
	}

	public Cliente atualizarCliente(Cliente cliente) {
		return clienteRepository.save(cliente);
	}

	public Cliente listarCliente(Long id) {
		Cliente cliente = (Cliente) clienteRepository.findById(id).orElse(null);
		return cliente;
	}

	public String deletarClienteporID(Long id) {
		clienteRepository.deleteById(id);
		return "Cliente de id " + id + " deletado com sucesso";
	}

}
