package edu.ifpb.webII.repository;

public interface UsuarioRepository {

}
