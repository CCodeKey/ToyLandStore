package edu.ifpb.webII;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToyLandStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
