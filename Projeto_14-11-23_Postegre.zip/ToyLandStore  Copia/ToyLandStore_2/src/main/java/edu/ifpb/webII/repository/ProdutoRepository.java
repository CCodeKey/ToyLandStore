package edu.ifpb.webII.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import edu.ifpb.webII.model.Produto;

public interface ProdutoRepository extends JpaRepository<Produto,Long> {
	
}