package edu.ifpb.webII.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.ifpb.webII.model.Produto;
import edu.ifpb.webII.repository.ProdutoRepository;

@Service
public class ProdutoService {

	@Autowired
	private ProdutoRepository produtoRepository;
	
	public List<Produto> listarProdutos() {
		return produtoRepository.findAll();
	}
	
	public Produto cadastrarProduto(Produto produto) {
		return produtoRepository.save(produto);
	}
	
	public Produto atualizarProduto(Produto produto) {
		return produtoRepository.save(produto);
	}
	
	public Produto listarProduto(Long id) {
		Produto produto = (Produto) produtoRepository.findById(id).orElse(null);
		return produto;
	}
	
	public String deletarProduto(Long id) {
		produtoRepository.deleteById(id);
		return "Produto de ID " + id + " deletado com sucesso!";
	}
}
