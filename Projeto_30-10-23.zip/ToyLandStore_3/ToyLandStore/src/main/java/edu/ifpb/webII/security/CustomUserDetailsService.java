package edu.ifpb.webII.security;

public class CustomUserDetailsService {

}
