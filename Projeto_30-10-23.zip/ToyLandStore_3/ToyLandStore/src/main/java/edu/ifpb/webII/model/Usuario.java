package edu.ifpb.webII.model;

public class Usuario {

}
