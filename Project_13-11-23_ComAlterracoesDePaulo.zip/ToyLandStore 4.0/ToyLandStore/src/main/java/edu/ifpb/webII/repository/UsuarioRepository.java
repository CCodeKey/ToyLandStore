package edu.ifpb.webII.repository;

import edu.ifpb.webII.model.Usuario;
import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Usuario findByEmail(String email);
    
    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value=""
			+ "update users"
			+ " set senha = :senha"
			+ " where email = :email", nativeQuery=true)
	void updateUser(@Param("email") String email, @Param("senha") String senha);
}